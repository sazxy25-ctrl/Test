# Saxzy Mod VIP source update

This package starts from the supplied `3105-main(1).zip` Xcode project.

Implemented in this pass:
- Rebranded app display/product name to `Saxzy Mod VIP`.
- Main navigation now exposes four tabs in this order: Home, App Data, Patch Files, Cleaner.
- Existing New, Sources, and Search repository tabs are not shown in the main tab navigation.
- Cleaner is connected to the existing `CleanerView`.
- Settings keeps the existing device/version/social/credits sections and adds Telegram support at https://t.me/mgthegod68.
- Added Khmer localization resource and Khmer option in the language picker; English remains available.
- Added GitHub Actions workflow for an unsigned iOS archive/IPA.

Important limitations:
- The original bundle identifier is intentionally unchanged (`com.apple.mobile.MobileHouseArrest`) so this source edit does not silently invalidate an existing provisioning profile. It should be replaced with an identifier owned by the app publisher before distribution, with a matching provisioning profile.
- The source tree still contains exploit and sandbox-escape code inherited from the original project. The workflow intentionally blocks until those components and references are removed. This archive is not yet a safe, build-ready IPA source.
- Xcode is not available in this environment; no iOS build or device test has been performed.
